const firebaseConfig = {
    apiKey: "AIzaSyDE6FeqGnUYZkGgaz4PU_TqK0v5CN2jqVc",
    authDomain: "smashkarts-dev2.firebaseapp.com",
    databaseURL: "https://smashkarts-dev2-default-rtdb.europe-west1.firebasedatabase.app",
    storageBucket: "smashkarts-dev2.appspot.com",
    messagingSenderId: "891339621024",
    appId: "1:891339621024:web:36ed91a95712ea9a99bfc5"
};
