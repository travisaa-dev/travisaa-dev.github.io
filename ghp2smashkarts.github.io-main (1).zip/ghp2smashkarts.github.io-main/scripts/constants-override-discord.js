'use strict';

enableFirebaseAnalytics = false;

var displayAdProvider = AdProviderDummy;
var videoAdProvider = AdProviderDummy;

pwCommonScriptSrc = ".proxy/scripts/ads-pw-common.js";
pwDisplayScriptSrc = ".proxy/scripts/ads-pw-display.js";
pwVideoScriptSrc = ".proxy/scripts/ads-pw-video.js";
adinplayDisplayScriptSrc = ".proxy/scripts/ads-adinplay-display.js";
adinplayVideoScriptSrc = ".proxy/scripts/ads-adinplay-video.js";
googleH5GamesVideoScriptSrc = ".proxy/scripts/ads-google-h5-games-video.js";


baitScriptSrc = ".proxy/scripts/banger.js";
ccWorkerScriptSrc = ".proxy/scripts/ccWorker.js";
